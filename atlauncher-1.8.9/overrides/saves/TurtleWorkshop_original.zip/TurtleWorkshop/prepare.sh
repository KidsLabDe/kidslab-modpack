#!/bin/bash
echo "cleaning up-"
rm ./playerdata/*
rm ./customnpc/playerdata/
rm ./stats/*
rm level.dat
cp level-adventure.dat level.dat

