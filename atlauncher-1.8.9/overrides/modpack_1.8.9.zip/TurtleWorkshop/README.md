# MinecraftWorld: TurtleWorkshop (Server-Version)

# Deutsch

Diese Welt stellt Aufgaben für eine Workshop mit der ComputerCraftEDU-Tutrle (https://computercraftedu.com/) zur Verfügung. 
Alle Aufgaben sind jeweils für 12 Teilnehmer ausgelegt. 

## Anforderungen
- CustomNPC Mod 
- Minecraft Forge 1.8.9
- Abenteuer-Modus für Teilnehmer

# English

This world gives you a basis for workshop with the ComputerCraftEDU-Tutrle (https://computercraftedu.com/). All challenges are build for 12 kids.


## Requirements
- CustomNPC Mod 
- Minecraft Forge 1.8.9
- Adventure-Mode for participants
